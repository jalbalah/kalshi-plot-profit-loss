# Computes P/L for all resolved markets using Kalshi's official SDK.

from kalshi_py import create_client
from kalshi_py.api.portfolio.get_settlements import sync as get_settlements
from kalshi_py.api.market.get_market import sync as get_market
from collections import defaultdict
import os
import matplotlib.pyplot as plt
import numpy as np

# ---------------------------------------------------------
# CONFIG - API Keys Required
# ---------------------------------------------------------

# Get API credentials from environment variables or set them here
API_KEY_ID = './key.id'
PRIVATE_KEY_PATH = './key.pem'

if not API_KEY_ID or not PRIVATE_KEY_PATH:
    print("ERROR: Kalshi API now requires API keys (not email/password)")
    print("To get your API keys:")
    print("  1. Log into https://kalshi.com with your Gmail account")
    print("  2. Go to Account Settings → API Keys")
    print("  3. Create a new API key and download the private key")
    print("  4. Set environment variables:")
    print("     - KALSHI_API_KEY_ID=your-api-key-id")
    print("     - KALSHI_PY_PRIVATE_KEY_PEM=path/to/private_key.pem")
    print("  Or edit this file and set API_KEY_ID and PRIVATE_KEY_PATH directly")
    exit(1)

# Load private key and set environment variable for kalshi-py
try:
    with open(API_KEY_ID, 'r') as f:
        api_key_id = f.read()
    with open(PRIVATE_KEY_PATH, 'r') as f:
        private_key_pem = f.read()
    os.environ['KALSHI_API_KEY_ID'] = api_key_id
    os.environ['KALSHI_PY_PRIVATE_KEY_PEM'] = private_key_pem
except Exception as e:
    print(f"ERROR: Failed to load private key from {PRIVATE_KEY_PATH}: {e}")
    exit(1)

# Initialize client using official SDK
CLIENT = create_client()

# ---------------------------------------------------------
# FETCH SETTLEMENTS (Resolved Trades)
# ---------------------------------------------------------

def fetch_all_settlements():
    """Fetch all settlements (resolved trades) with pagination"""
    all_settlements = []
    cursor = None
   
    while True:
        try:
            resp = get_settlements(client=CLIENT, limit=100, cursor=cursor)
           
            if resp and hasattr(resp, 'settlements'):
                all_settlements.extend(resp.settlements)
                cursor = resp.cursor if hasattr(resp, 'cursor') and resp.cursor else None
                if not cursor:
                    break
            else:
                break
        except Exception as e:
            print(f"Error fetching settlements: {e}")
            break
   
    return all_settlements

# ---------------------------------------------------------
# P/L CALCULATION
# ---------------------------------------------------------

def compute_pl():
    settlements = fetch_all_settlements()
   
    results = {}
    market_names = {}  # Store readable market names
    total_pl = 0.0
   
    for settlement in settlements:
        ticker = settlement.ticker if hasattr(settlement, 'ticker') else ''
        if not ticker:
            continue
       
        # Fetch market name for readability
        try:
            market_info = get_market(client=CLIENT, ticker=ticker)
            if hasattr(market_info, 'market') and hasattr(market_info.market, 'title'):
                market_names[ticker] = market_info.market.title
            else:
                market_names[ticker] = ticker
        except:
            market_names[ticker] = ticker
       
        # Extract settlement data (all costs are in cents)
        market_result = settlement.market_result.value if hasattr(settlement, 'market_result') and hasattr(settlement.market_result, 'value') else ''
        yes_count = settlement.yes_count if hasattr(settlement, 'yes_count') else 0
        no_count = settlement.no_count if hasattr(settlement, 'no_count') else 0
        yes_total_cost = settlement.yes_total_cost if hasattr(settlement, 'yes_total_cost') and settlement.yes_total_cost else 0
        no_total_cost = settlement.no_total_cost if hasattr(settlement, 'no_total_cost') and settlement.no_total_cost else 0
       
        # Calculate payout: winning contracts pay $1 each (100 cents)
        if market_result == 'yes':
            payout_dollars = yes_count * 1.0
        elif market_result == 'no':
            payout_dollars = no_count * 1.0
        else:
            payout_dollars = 0.0
       
        # Get revenue if available (revenue field may be more accurate than calculated payout)
        revenue_dollars = (settlement.revenue / 100.0) if hasattr(settlement, 'revenue') and settlement.revenue else 0.0
       
        # Calculate P/L in dollars
        total_cost_dollars = (yes_total_cost + no_total_cost) / 100.0
       
        # Use revenue if available and non-zero, otherwise calculate from payout
        # Revenue field in settlements is the actual amount received
        if revenue_dollars != 0:
            pl = revenue_dollars - total_cost_dollars
        else:
            # Calculate payout from winning contracts if revenue is 0
            pl = payout_dollars - total_cost_dollars
       
        results[ticker] = pl
        total_pl += pl
   
    return results, total_pl, market_names


# ---------------------------------------------------------
# PLOTTING
# ---------------------------------------------------------

def plot_pl(market_pl, total, market_names):
    """Create a bar chart of P/L for each market"""
    # Sort by P/L value
    sorted_markets = sorted(market_pl.items(), key=lambda x: x[1])
    tickers = [m[0] for m in sorted_markets]
    pl_values = [m[1] for m in sorted_markets]
   
    # Get readable names, truncate if too long
    readable_names = []
    for ticker in tickers:
        name = market_names.get(ticker, ticker)
        # Truncate long names to make them more readable
        if len(name) > 60:
            name = name[:57] + "..."
        readable_names.append(name)
   
    # Create figure with appropriate size (wider for longer names)
    fig, ax = plt.subplots(figsize=(18, 10))
   
    # Create color map: green for positive, red for negative
    colors = ['green' if v >= 0 else 'red' for v in pl_values]
   
    # Create bar chart
    bars = ax.barh(range(len(tickers)), pl_values, color=colors, alpha=0.7)
   
    # Add value labels on bars
    for i, (bar, value) in enumerate(zip(bars, pl_values)):
        width = bar.get_width()
        label_x = width + (max(pl_values) - min(pl_values)) * 0.01 if width >= 0 else width - (max(pl_values) - min(pl_values)) * 0.01
        ax.text(label_x, bar.get_y() + bar.get_height()/2,
                f'${value:.2f}',
                ha='left' if width >= 0 else 'right',
                va='center', fontsize=9, fontweight='bold')
   
    # Set y-axis labels with readable names (no truncation)
    readable_names_full = [market_names.get(ticker, ticker) for ticker in tickers]
    ax.set_yticks(range(len(tickers)))
    ax.set_yticklabels(readable_names_full, fontsize=10)
   
    # Add grid
    ax.grid(axis='x', alpha=0.3, linestyle='--')
    ax.axvline(x=0, color='black', linewidth=0.8, linestyle='-')
   
    # Labels and title
    ax.set_xlabel('Profit/Loss ($)', fontsize=12, fontweight='bold')
    ax.set_title(f'P/L by Market (Total: ${total:.2f})', fontsize=14, fontweight='bold', pad=20)
   
    # Adjust layout to ensure labels are fully visible
    # Increase left margin significantly to accommodate longer text
    plt.subplots_adjust(left=0.50, right=0.95, top=0.95, bottom=0.1)
   
    # Save plot
    plt.savefig('kalshi_pl_plot.png', dpi=300, bbox_inches='tight')
    print(f"\nPlot saved as 'kalshi_pl_plot.png'")
   
    # Show plot
    plt.show()


# ---------------------------------------------------------
# MAIN
# ---------------------------------------------------------

if __name__ == "__main__":
    market_pl, total, market_names = compute_pl()
    for m, v in sorted(market_pl.items()):
        print(f"{m}: {v:.2f}")
    print("TOTAL P/L:", f"{total:.2f}")
   
    # Generate plot
    plot_pl(market_pl, total, market_names)