1. Go to kalshi.com and login
2. Click the three lines at the top right corner
3. Click Account & Security
4. Under API Keys click Create Key then name it and click Create
5. Before closing the window (can only view once):
- Copy the API key id into key.id file
- Copy the Private key into key.pem file